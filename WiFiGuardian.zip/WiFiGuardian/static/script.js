// WiFi Security Testing Tool - Frontend JavaScript
// Developer: SHAKIR HOSSAIN | Website: https://shakir.com.bd

class WiFiSecurityTool {
    constructor() {
        this.isScanning = false;
        this.isAttacking = false;
        this.currentTarget = null;
        this.statusUpdateInterval = null;
        
        this.initializeEventListeners();
        this.updateStatus();
        this.startStatusUpdates();
    }

    initializeEventListeners() {
        // Control buttons
        document.getElementById('setupBtn').addEventListener('click', () => this.setupSystem());
        document.getElementById('monitorBtn').addEventListener('click', () => this.toggleMonitorMode());
        document.getElementById('scanBtn').addEventListener('click', () => this.scanNetworks());
        document.getElementById('stopBtn').addEventListener('click', () => this.stopOperation());
        
        // Attack modal
        document.getElementById('confirmAttackBtn').addEventListener('click', () => this.confirmAttack());
        
        // Auto-refresh networks every 30 seconds during scanning
        setInterval(() => {
            if (this.isScanning) {
                this.refreshNetworks();
            }
        }, 30000);
    }

    startStatusUpdates() {
        this.statusUpdateInterval = setInterval(() => {
            this.updateStatus();
        }, 2000);
    }

    async updateStatus() {
        try {
            const response = await fetch('/api/status');
            const data = await response.json();
            
            if (data.success) {
                this.updateStatusIndicators(data);
                this.updateDependencyStatus(data.dependencies);
                this.updateOperationStatus(data.current_operation);
                this.updateButtonStates(data);
            }
        } catch (error) {
            console.error('Status update failed:', error);
        }
    }

    updateStatusIndicators(data) {
        // Root status
        const rootStatus = document.getElementById('rootStatus');
        const rootText = document.getElementById('rootText');
        if (data.root_access) {
            rootStatus.className = 'badge bg-success';
            rootText.textContent = 'Active';
        } else {
            rootStatus.className = 'badge bg-danger';
            rootText.textContent = 'Required';
        }

        // Monitor mode status
        const monitorStatus = document.getElementById('monitorStatus');
        const monitorText = document.getElementById('monitorText');
        if (data.monitor_mode_active) {
            monitorStatus.className = 'badge bg-success';
            monitorText.textContent = 'Enabled';
        } else {
            monitorStatus.className = 'badge bg-secondary';
            monitorText.textContent = 'Disabled';
        }
    }

    updateDependencyStatus(dependencies) {
        const statusDiv = document.getElementById('dependencyStatus');
        if (!dependencies) {
            statusDiv.innerHTML = '<div class="text-muted">Click "Install Dependencies" to check</div>';
            return;
        }

        let html = '';
        for (const [name, installed] of Object.entries(dependencies)) {
            const statusClass = installed ? 'text-success' : 'text-danger';
            const statusIcon = installed ? 'fa-check' : 'fa-times';
            const statusText = installed ? 'OK' : 'Missing';
            
            html += `
                <div class="dependency-item">
                    <span class="dependency-name">${name}</span>
                    <span class="dependency-status ${statusClass}">
                        <i class="fas ${statusIcon}"></i> ${statusText}
                    </span>
                </div>
            `;
        }
        statusDiv.innerHTML = html;
    }

    updateOperationStatus(operation) {
        const statusElement = document.getElementById('operationStatus');
        if (operation) {
            statusElement.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${operation}`;
            statusElement.className = 'text-primary';
        } else {
            statusElement.innerHTML = '<i class="fas fa-info-circle"></i> Ready';
            statusElement.className = 'text-muted';
        }
    }

    updateButtonStates(data) {
        const setupBtn = document.getElementById('setupBtn');
        const monitorBtn = document.getElementById('monitorBtn');
        const scanBtn = document.getElementById('scanBtn');
        const stopBtn = document.getElementById('stopBtn');

        // Setup button
        setupBtn.disabled = !!data.current_operation;

        // Monitor button
        monitorBtn.disabled = !data.root_access || !!data.current_operation;
        if (data.monitor_mode_active) {
            monitorBtn.innerHTML = '<i class="fas fa-toggle-on"></i> Disable Monitor Mode';
            monitorBtn.className = 'btn btn-danger btn-sm w-100';
        } else {
            monitorBtn.innerHTML = '<i class="fas fa-toggle-off"></i> Enable Monitor Mode';
            monitorBtn.className = 'btn btn-warning btn-sm w-100';
        }

        // Scan button
        scanBtn.disabled = !data.monitor_mode_active || !!data.current_operation;

        // Stop button
        stopBtn.disabled = !data.current_operation;
    }

    async setupSystem() {
        try {
            this.showButton('setupBtn', 'Installing...', true);
            
            const response = await fetch('/api/setup', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'}
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('Setup started in background. Check status above.', 'info');
            } else {
                this.showAlert(`Setup failed: ${data.error}`, 'danger');
            }
        } catch (error) {
            this.showAlert(`Setup error: ${error.message}`, 'danger');
        } finally {
            setTimeout(() => {
                this.resetButton('setupBtn', '<i class="fas fa-download"></i> Install Dependencies');
            }, 2000);
        }
    }

    async toggleMonitorMode() {
        try {
            this.showButton('monitorBtn', 'Toggling...', true);
            
            const response = await fetch('/api/monitor/toggle', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'}
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert(data.message, 'success');
            } else {
                this.showAlert(`Monitor mode error: ${data.error}`, 'danger');
            }
        } catch (error) {
            this.showAlert(`Monitor mode error: ${error.message}`, 'danger');
        }
    }

    async scanNetworks() {
        try {
            this.isScanning = true;
            this.showButton('scanBtn', 'Scanning...', true);
            
            const response = await fetch('/api/scan', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'}
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('Network scan started. Results will appear below.', 'info');
                
                // Start checking for results
                setTimeout(() => this.refreshNetworks(), 5000);
            } else {
                this.showAlert(`Scan failed: ${data.error}`, 'danger');
                this.isScanning = false;
            }
        } catch (error) {
            this.showAlert(`Scan error: ${error.message}`, 'danger');
            this.isScanning = false;
        }
    }

    async refreshNetworks() {
        try {
            const response = await fetch('/api/networks');
            const data = await response.json();
            
            if (data.success) {
                this.updateNetworksTable(data.networks);
            }
        } catch (error) {
            console.error('Failed to refresh networks:', error);
        }
    }

    updateNetworksTable(networks) {
        const tbody = document.getElementById('networksBody');
        const countElement = document.getElementById('networkCount');
        
        countElement.textContent = `${networks.length} networks`;
        
        if (networks.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-muted">
                        ${this.isScanning ? 'Scanning for networks...' : 'No networks found. Try scanning again.'}
                    </td>
                </tr>
            `;
            return;
        }

        let html = '';
        networks.forEach(network => {
            const wpsPins = this.formatWPSPins(network.wps_pins || []);
            const signalStrength = this.formatSignalStrength(network.power);
            const encryption = this.formatEncryption(network.encryption);
            
            html += `
                <tr>
                    <td>
                        <strong>${this.escapeHtml(network.essid)}</strong>
                    </td>
                    <td>
                        <code class="small">${network.bssid}</code>
                    </td>
                    <td>
                        <span class="badge bg-light text-dark">${network.channel}</span>
                    </td>
                    <td>
                        ${signalStrength}
                        <small class="text-muted">${network.power} dBm</small>
                    </td>
                    <td>${encryption}</td>
                    <td>
                        <div class="wps-pins">${wpsPins}</div>
                    </td>
                    <td>
                        <button class="btn btn-outline-danger btn-sm" 
                                onclick="wifiTool.showAttackModal('${network.bssid}', '${this.escapeHtml(network.essid)}', ${JSON.stringify(network.wps_pins || []).replace(/"/g, '&quot;')})">
                            <i class="fas fa-crosshairs"></i> Attack
                        </button>
                    </td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
    }

    formatWPSPins(pins) {
        if (!pins || pins.length === 0) {
            return '<small class="text-muted">None</small>';
        }
        
        return pins.slice(0, 3).map(pin => 
            `<span class="badge bg-secondary pin-badge">${pin.pin}</span>`
        ).join(' ') + (pins.length > 3 ? '<small class="text-muted">...</small>' : '');
    }

    formatSignalStrength(power) {
        const strength = Math.max(0, Math.min(4, Math.floor((power + 100) / 25)));
        let html = '<div class="signal-strength">';
        for (let i = 1; i <= 4; i++) {
            html += `<div class="signal-bar ${i <= strength ? 'active' : ''}"></div>`;
        }
        html += '</div>';
        return html;
    }

    formatEncryption(encryption) {
        if (!encryption) return '<span class="badge bg-secondary">Unknown</span>';
        
        if (encryption.includes('WPA')) {
            return '<span class="badge bg-warning text-dark">WPA/WPA2</span>';
        } else if (encryption.includes('WEP')) {
            return '<span class="badge bg-danger">WEP</span>';
        } else if (encryption.includes('OPEN')) {
            return '<span class="badge bg-success">Open</span>';
        } else {
            return `<span class="badge bg-secondary">${encryption}</span>`;
        }
    }

    showAttackModal(bssid, essid, wpsPins) {
        this.currentTarget = { bssid, essid, wpsPins };
        
        // Update modal content
        document.getElementById('targetInfo').innerHTML = `
            <strong>ESSID:</strong> ${this.escapeHtml(essid)}<br>
            <strong>BSSID:</strong> <code>${bssid}</code>
        `;
        
        const pinsHtml = wpsPins.length > 0 ? 
            wpsPins.map(pin => `
                <div class="pin-item">
                    <span class="pin-code">${pin.pin}</span>
                    <span class="pin-algorithm">${pin.name}</span>
                </div>
            `).join('') :
            '<div class="text-muted">No WPS pins available</div>';
        
        document.getElementById('availablePins').innerHTML = `<div class="pin-list">${pinsHtml}</div>`;
        
        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('attackModal'));
        modal.show();
    }

    async confirmAttack() {
        if (!this.currentTarget) return;
        
        try {
            // Hide modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('attackModal'));
            modal.hide();
            
            this.isAttacking = true;
            this.showAlert(`Starting attack on ${this.currentTarget.essid}...`, 'warning');
            
            const response = await fetch('/api/attack', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    bssid: this.currentTarget.bssid,
                    essid: this.currentTarget.essid
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('Attack started. Monitor the status above for results.', 'info');
                document.getElementById('resultsCard').style.display = 'block';
                document.getElementById('attackResults').innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-spinner fa-spin"></i> 
                        Attack in progress on ${this.escapeHtml(this.currentTarget.essid)}...
                    </div>
                `;
            } else {
                this.showAlert(`Attack failed: ${data.error}`, 'danger');
                this.isAttacking = false;
            }
        } catch (error) {
            this.showAlert(`Attack error: ${error.message}`, 'danger');
            this.isAttacking = false;
        }
    }

    async stopOperation() {
        try {
            const response = await fetch('/api/stop', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'}
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('Operation stopped.', 'info');
                this.isScanning = false;
                this.isAttacking = false;
                this.resetButton('scanBtn', '<i class="fas fa-search"></i> Scan Networks');
            } else {
                this.showAlert(`Stop failed: ${data.error}`, 'danger');
            }
        } catch (error) {
            this.showAlert(`Stop error: ${error.message}`, 'danger');
        }
    }

    showButton(buttonId, text, disabled = false) {
        const button = document.getElementById(buttonId);
        button.innerHTML = disabled ? `<i class="fas fa-spinner fa-spin"></i> ${text}` : text;
        button.disabled = disabled;
    }

    resetButton(buttonId, originalText) {
        const button = document.getElementById(buttonId);
        button.innerHTML = originalText;
        button.disabled = false;
    }

    showAlert(message, type) {
        // Create alert element
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Insert at top of main content
        const mainContent = document.querySelector('.col-md-8');
        mainContent.insertBefore(alertDiv, mainContent.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the tool when page loads
let wifiTool;
document.addEventListener('DOMContentLoaded', () => {
    wifiTool = new WiFiSecurityTool();
});
